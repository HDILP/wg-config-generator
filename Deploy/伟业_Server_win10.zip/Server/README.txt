Server: 伟业
IP: 117.72.84.199
VPN: 10.66.66.1
Port: 51820

1. Install WireGuard
2. Import server.conf
3. Activate
